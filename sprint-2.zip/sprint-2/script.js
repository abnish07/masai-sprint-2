// function test(){
//     alert("test")
// }


function getResult(){

    var totalMarks = 500;
    var name = document.getElementById("name").value
    var stdClass = document.getElementById("stdClass").value
    var stdSection = document.getElementById("sectionField").value
    var marks = document.getElementsByName("marks")
    // var image = document.getElementById("imageId").innerHTML = "<img src = '/home/abnish/nj_101_abnish/Projects/masai/sprint-2/resources/rahul.jpeg'>";
    var len = marks.length;
    var total = 0;

    //calcutaing Total Marks

    for ( var i = 0; i<len; i++)
    {
        // if (parseInt(marks[i]) <= 100){
            total = total + parseInt(marks[i].value);
        }
        // else{
        //     alert("please enter correct marks (<=100)")
        // }
    

    var avgMarks = total/len;
    
    var percentage = (total*100)/500;

    if(avgMarks > 60 && avgMarks <= 100){
        grade = "A" 
        result = "First Division"
    }
    else if(avgMarks < 60 && avgMarks > 45){
        grade = "B"
        result = "Second Division"
    }
    else if( avgMarks < 45 && avgMarks > 30){
        grade = "C"
        result = "Third Division"
    }
    else {
        grade = "D"
        result = "fail"
    }

    document.getElementById("nameStd").value = name
    document.getElementById("displayClass").value = stdClass
    document.getElementById("displaySection").value = stdSection
    document.getElementById("displayMarks").value = total
    document.getElementById("displayTotalMarks").value = totalMarks
    document.getElementById("displayAvg").value = avgMarks
    document.getElementById("displayGrade").value = grade
    document.getElementById("displayPercent").value = percentage
    document.getElementById("displayResult").value = result
    document.getElementById("imageId").value

     resultColor = document.getElementById("displayResult")
    if (result == "First Division" || result == "Second Division" || result == "Third Division"){
        resultColor.style.backgroundColor = "green"

    }
    else{
        resultColor.style.backgroundColor = "red"

    }

    var sName = []
    var sClass = []
    var sSection = []
    var sTotal = []
    var sAvg = []
    var sGrade = []
    var sResult = []
    
    sName.push(name)
    sClass.push(stdClass)
    sSection.push(stdSection)
    sTotal.push(total)
    sAvg.push(avgMarks)
    sGrade.push(grade)
    sResult.push(result)

    var res = document.getElementById("res")
    res.innerHTML += "Name: " + sName.join("|")+ "</br>";
    res.innerHTML += "Class: " + sClass.join("|")+ "</br>";
    res.innerHTML += "Section: " + sSection.join("|")+"</br>";
    res.innerHTML += "Total Marks: " + sTotal.join("|")+ "</br>";
    res.innerHTML += "Average Marks: " + sAvg.join("|")+ "</br>";
    res.innerHTML += "Grade: " + sGrade.join("|")+ "</br>";
    res.innerHTML += "Result: " + sResult.join("|")+ "</br>" + "</br>";


    reset()

    var sAbove = []
    var sBelow = []

    for ( var i = 0; i<sAvg.length; i++){
        if(sAvg[i]> 50)
        {
            sAbove.push(sAvg[i])
        }
        else{
            sBelow.push(sAvg[i])
        }
    }


}

function reset(){
    var name = document.getElementById("name").value="";
    var name = document.getElementById("name").value ="";
    var stdClass = document.getElementById("stdClass").value="";
    var stdSection = document.getElementById("sectionField").value= "";
    var examSelection = document.getElementById("examType").value="";
    var marks = document.getElementsByName("marks")
    var len = marks.length
    for(var i = 0; i< len; i++){
        var marks = document.getElementsByName("marks");
        marks[i].value = "";
    }
}

// function belowAvg(){
//     document.getElementById("displayAvg").value = avgMarks

//     var sBelow = []
//     for (var i = 0; i< sAvg.length; i++){
//         if(sAvg[i]< 50){
//             sBelow.push(sAvg[i])
//         }
//     }
// }

// function aboveAvg(){
//     var marks = document.getElementsByName("marks")
//     var len = marks.length;
//     var total = 0;
//     for ( var i = 0; i<len; i++)
//     {
//             total = total + parseInt(marks[i].value);
//         }
    

//     var avgMarks = total/len;

//     var sAvg = []
//     sAvg.push(avgMarks)

//     var sAbove = []
//     for (var i = 0; i< sAvg.length; i++){
//         if(sAvg[i]> 50)
//         {
//             sAbove.push(sAvg[i])
//         }
//     }
//     var res1 = document.getElementById("res1")

//     res1.innerHTML += "Average Marks: " + sAbove.join("|")+ "</br>";

// }





